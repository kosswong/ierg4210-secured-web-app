<?php
if (!defined('IERG4210ADMIN')) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}
?>
<div class="card bg-danger text-white shadow">
    <div class="card-body">
        ERROR!
    </div>
</div>