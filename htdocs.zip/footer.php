<footer class="container">
    <p>&copy; Company 2021 | <a href='../admin/categories.php'>Admin</a></p>

</footer>


<script src="js/jquery-3.2.1.slim.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>